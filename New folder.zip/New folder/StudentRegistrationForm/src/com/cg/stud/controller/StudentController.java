package com.cg.stud.controller;

import java.io.IOException;
import java.time.LocalDate;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class LoginController
 */
@WebServlet("/StudentController")
public class StudentController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public StudentController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    RequestDispatcher rd=null;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String Studentname =request.getParameter("Studentname");
		String Studentdept =request.getParameter("Studentdept");
		String marks=request.getParameter("12thMarks");
		String mobile_number=request.getParameter("Mobilenumber");
		String percentage=request.getParameter("Percentage");
		
			
			HttpSession session=request.getSession(true);
			
			session.setAttribute("Studentname",Studentname);
			session.setAttribute("Studentdept",Studentdept);
			session.setAttribute("12thMarks",marks );
			session.setAttribute("Mobilenumber",mobile_number);
			session.setAttribute("Percentage", percentage);
			
			rd=request.getRequestDispatcher("Success.html");
			rd.forward(request, response);
			
		}
		

		/**
		 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
		 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}






